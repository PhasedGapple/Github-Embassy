;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="bbd1f08d-286c-a118-a431-d102491b1306")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,381989,e=>{"use strict";var r=e.i(843476),t=e.i(618566),i=e.i(271645);let n=[[1,5],[1,6],[2,5],[2,6],[11,5],[11,6],[11,7],[12,4],[12,8],[13,3],[13,9],[14,3],[14,9],[15,6],[16,4],[16,8],[17,5],[17,6],[17,7],[18,6],[21,3],[21,4],[21,5],[22,3],[22,4],[22,5],[23,2],[23,6],[25,1],[25,2],[25,6],[25,7],[35,3],[35,4],[36,3],[36,4]],l=function e(r){if(1===r)return[[0]];let t=e(r/2),i=[];for(let e=0;e<r;e++){i.push([]);for(let n=0;n<r;n++){let l=(e<r/2?0:2)+(n<r/2?0:1);i[e].push(4*t[e%(r/2)][n%(r/2)]+[0,2,3,1][l])}}return i}(16),a=l.length,o=a*a,c=6/64,u=`#version 300 es
precision highp float;
out vec2 vUv;
void main() {
  vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
  vUv = p;
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
`,d=`#version 300 es
precision highp float;
precision highp sampler2D;

uniform sampler2D uState;  // r = alive, g = blast energy
uniform sampler2D uMask;   // r = the dither band, g = that column's surface row
uniform ivec2 uGridSize;   // (cols, rows)
uniform int uMinSurfaceRow; // the highest surface row, which g is an offset from
uniform int uGen;          // generation counter, drives the twinkle
out vec4 outColor;

const int ABSORB_ROWS = 1;
const int BLAST_FLOOR_ROWS = 4;
const float TWINKLE_RATE = 0.0700;
const float TWINKLE_PERIOD = 6.0;
const float BLAST_DECAY = 0.0230;
const float BLAST_SPREAD = 0.0500;
const float BLAST_CLEAR = 0.3000;
const float BLAST_PARTICLE_LO = 0.0800;
const float BLAST_PARTICLE_DENSITY = 0.4000;

bool inGrid(ivec2 c) {
  return c.x >= 0 && c.y >= 0 && c.x < uGridSize.x && c.y < uGridSize.y;
}

int cell(ivec2 c) {
  if (!inGrid(c)) return 0;
  return int(texelFetch(uState, c, 0).r > 0.5);
}

float energyAt(ivec2 c) {
  if (!inGrid(c)) return 0.0;
  return texelFetch(uState, c, 0).g;
}

int surfaceAt(int x) {
  int cx = clamp(x, 0, uGridSize.x - 1);
  return uMinSurfaceRow + int(texelFetch(uMask, ivec2(cx, 0), 0).g * 255.0 + 0.5);
}

float hash(vec3 p) {
  p = fract(p * 0.1031);
  p += dot(p, p.yzx + 33.33);
  return fract((p.x + p.y) * p.z);
}

void main() {
  ivec2 c = ivec2(gl_FragCoord.xy);

  int surface = surfaceAt(c.x);
  int absorbRow =
      min(min(surfaceAt(c.x - 1), surface), surfaceAt(c.x + 1)) - ABSORB_ROWS;

  float e = energyAt(c) - BLAST_DECAY;
  for (int dy = -1; dy <= 1; dy++) {
    for (int dx = -1; dx <= 1; dx++) {
      if (dx == 0 && dy == 0) continue;
      float cost = BLAST_SPREAD * ((dx != 0 && dy != 0) ? 1.4142 : 1.0);
      e = max(e, energyAt(c + ivec2(dx, dy)) - cost);
    }
  }
  if (c.y == absorbRow) {
    int incoming = cell(ivec2(c.x - 1, c.y - 1)) + cell(ivec2(c.x, c.y - 1)) +
                   cell(ivec2(c.x + 1, c.y - 1));
    if (incoming > 0) e = 1.0;
  }
  e = clamp(e, 0.0, 1.0);

  if (c.y >= surface) {
    float m = texelFetch(uMask, c, 0).r;
    bool alive = m > 0.5;
    if (m > 0.2 && m < 0.8) {
      float slice = floor(float(uGen) / TWINKLE_PERIOD + hash(vec3(vec2(c), 7.0)) * 4.0);
      if (hash(vec3(vec2(c), slice)) < TWINKLE_RATE) alive = !alive;
    }
    if (c.y < uGridSize.y - BLAST_FLOOR_ROWS) {
      if (e > BLAST_CLEAR) alive = false;
      else if (e > BLAST_PARTICLE_LO &&
               hash(vec3(vec2(c), 3.7)) < BLAST_PARTICLE_DENSITY) alive = true;
    }

    outColor = vec4(alive ? 1.0 : 0.0, e, 0.0, 1.0);
    return;
  }

  if (c.y >= absorbRow) {
    outColor = vec4(0.0, e, 0.0, 1.0);
    return;
  }

  int n = 0;
  n += cell(c + ivec2(-1, -1));
  n += cell(c + ivec2( 0, -1));
  n += cell(c + ivec2( 1, -1));
  n += cell(c + ivec2(-1,  0));
  n += cell(c + ivec2( 1,  0));
  n += cell(c + ivec2(-1,  1));
  n += cell(c + ivec2( 0,  1));
  n += cell(c + ivec2( 1,  1));

  int alive = cell(c);
  int nextAlive = 0;
  if (alive == 1) {
    nextAlive = (n == 2 || n == 3) ? 1 : 0;
  } else {
    nextAlive = (n == 3) ? 1 : 0;
  }

  float v = nextAlive == 1 ? 1.0 : 0.0;
  outColor = vec4(v, e, 0.0, 1.0);
}
`,f=`#version 300 es
precision highp float;
precision highp sampler2D;

uniform sampler2D uState;
uniform ivec2 uGridSize;
uniform float uCellPx;
uniform vec3 uCellColor;

out vec4 outColor;

void main() {
  vec2 frag = gl_FragCoord.xy;
  ivec2 cellCoord = ivec2(floor(frag / uCellPx));
  int x = cellCoord.x;
  int y = (uGridSize.y - 1) - cellCoord.y;

  if (x < 0 || y < 0 || x >= uGridSize.x || y >= uGridSize.y) {
    outColor = vec4(0.0);
    return;
  }

  float alive = texelFetch(uState, ivec2(x, y), 0).r;
  float a = step(0.5, alive);
  outColor = vec4(uCellColor, a);
}
`;function s(e,r,t){let i=e.createShader(r);if(!i)throw Error("Failed to create shader");if(e.shaderSource(i,t),e.compileShader(i),!e.getShaderParameter(i,e.COMPILE_STATUS)){let r=e.getShaderInfoLog(i)??"Unknown shader compile error";throw e.deleteShader(i),Error(r)}return i}function h(e,r,t){let i=s(e,e.VERTEX_SHADER,r),n=s(e,e.FRAGMENT_SHADER,t),l=e.createProgram();if(!l)throw Error("Failed to create program");if(e.attachShader(l,i),e.attachShader(l,n),e.linkProgram(l),e.deleteShader(i),e.deleteShader(n),!e.getProgramParameter(l,e.LINK_STATUS)){let r=e.getProgramInfoLog(l)??"Unknown program link error";throw e.deleteProgram(l),Error(r)}return l}function m(e,r,t,i,n=2){let l=e.createTexture();if(!l)throw Error("Failed to create texture");return e.bindTexture(e.TEXTURE_2D,l),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE),e.pixelStorei(e.UNPACK_ALIGNMENT,1),e.texImage2D(e.TEXTURE_2D,0,1===n?e.R8:e.RG8,r,t,0,1===n?e.RED:e.RG,e.UNSIGNED_BYTE,i??null),e.bindTexture(e.TEXTURE_2D,null),l}function v(e,r){let t=e.createFramebuffer();if(!t)throw Error("Failed to create framebuffer");e.bindFramebuffer(e.FRAMEBUFFER,t),e.framebufferTexture2D(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,r,0);let i=e.checkFramebufferStatus(e.FRAMEBUFFER);if(e.bindFramebuffer(e.FRAMEBUFFER,null),i!==e.FRAMEBUFFER_COMPLETE)throw e.deleteFramebuffer(t),Error(`Incomplete framebuffer: ${i}`);return t}function x(e,r){let t=Math.imul(e,0x165667b1)+Math.imul(r,0x27d4eb2f);return(((t=Math.imul(t^t>>>13,0x4bf19f61))^t>>>16)>>>0)/0x100000000}function E(e,r){let t=Math.floor(e),i=e-t,n=i*i*(3-2*i);return x(t,r)*(1-n)+x(t+1,r)*n}let T=function e(r){if(1===r)return[[0]];let t=e(r/2),i=[];for(let e=0;e<r;e++){i.push([]);for(let n=0;n<r;n++){let l=(e<r/2?0:2)+(n<r/2?0:1);i[e].push(4*t[e%(r/2)][n%(r/2)]+[0,2,3,1][l])}}return i}(16),g=6/64;function R(e,r){let t=Math.imul(e,0x165667b1)+Math.imul(r,0x27d4eb2f);return(((t=Math.imul(t^t>>>13,0x4bf19f61))^t>>>16)>>>0)/0x100000000}function A(e,r){let t=Math.floor(e),i=e-t,n=i*i*(3-2*i);return R(t,r)*(1-n)+R(t+1,r)*n}let p={ink:null,govuk:null};function b({tone:e="ink"}){let t=function(e){if(p[e])return p[e];let r="govuk"===e?"#006B3F":"#000",t=function(e={}){let r=e.floor??0,t=e.ceiling??1,i=e.ease??2,n=new Uint8Array(320);for(let e=0;e<20;e++){let a=(e-0)/19,o=T[e%16];for(let c=0;c<16;c++){var l;let u=r+(t-r)*Math.pow(a,i)+(.68*A((l=c)/11,3)+.32*A(l/4.07+11.3,12)-.5)*.3*(1-a),d=(o[c%16]+(R(c,e)-.5)*4)/256,f=u>=.92,s=f||u>d,h=!f&&Math.abs(u-d)<g;n[16*e+c]=s?h?170:255:85*!!h}}return n}(),i=[];for(let e=0;e<20;e++)for(let n=0;n<16;n++){let l=t[16*e+n];(255===l||170===l)&&i.push(`<rect x="${10*n}" y="${10*e}" width="10" height="10" fill="${r}"/>`)}let n=`<svg xmlns="http://www.w3.org/2000/svg" width="160" height="200" viewBox="0 0 160 200"><rect width="100%" height="100%" fill="#fffbf1"/>${i.join("")}</svg>`;return p[e]=`url("data:image/svg+xml,${encodeURIComponent(n)}")`,p[e]}(e);return(0,r.jsx)("div",{"aria-hidden":"true",style:{height:"200px",backgroundImage:t,backgroundRepeat:"repeat-x",backgroundSize:"160px 200px",backgroundPosition:"bottom left",imageRendering:"pixelated",backgroundColor:"#fffbf1"}})}function S({children:e,className:t="",tone:s="ink",dither:T=!0}){let g=(0,i.useRef)(null),R=(0,i.useRef)(null),A="govuk"===s,p={paddingBottom:T?"calc(200px + 2.5rem)":"2.5rem"};return(0,i.useEffect)(()=>{let e=g.current;if(!e||window.matchMedia("(prefers-reduced-motion: reduce)").matches)return;let r=null;try{r=function(e,r={}){let t=r.cellSize??10,i=r.speedMs??100,s=r.ditherRows??20,T=r.cellColor??[0,0,0],g=e.getContext("webgl2",{alpha:!0,antialias:!1,depth:!1,stencil:!1,premultipliedAlpha:!1,powerPreference:"low-power"});if(!g)throw Error("WebGL2 not available (needed for shader-based Game of Life).");let R=Math.min(2,window.devicePixelRatio||1),A=h(g,u,d),p=h(g,u,f),b=g.createVertexArray();if(!b)throw Error("Failed to create VAO");let S=0,w=0,_=0,F=0,L=null,M=null,y=null,U=null,C=null,P=()=>{U&&g.deleteFramebuffer(U),C&&g.deleteFramebuffer(C),L&&g.deleteTexture(L),M&&g.deleteTexture(M),y&&g.deleteTexture(y),U=C=null,L=M=y=null},D=()=>{var r,i,u;let d,f,h,T,A,p=e.parentElement,b=p?.clientWidth??window.innerWidth,F=p?.clientHeight??window.innerHeight,D=Math.max(80,Math.ceil(b/t)),N=Math.max(s+4,Math.floor(F/t));if(D===S&&N===w)return;let B=(S=D)*t,I=(w=N)*t;e.style.width=`${B}px`,e.style.height=`${I}px`,e.width=Math.round(B*R),e.height=Math.round(I*R),P();let G=function(e,r,t){let i=new Uint8Array(e*r),n=new Int32Array(e).fill(r),u=Math.min(t,r),d=r-u;for(let t=d;t<r;t++){let r=(t-d)/Math.max(1,u-1),s=l[t%a];for(let l=0;l<e;l++){var f;let u=Math.pow(r,2)+(.68*E((f=l)/11,3)+.32*E(f/4.07+11.3,12)-.5)*.3*(1-r),d=(s[l%a]+(x(l,t)-.5)*4)/o,h=u>=.92,m=h||u>d,v=!h&&Math.abs(u-d)<c;m?(i[t*e+l]=v?170:255,t<n[l]&&(n[l]=t)):v&&(i[t*e+l]=85)}}return{mask:i,surface:n}}(S,w,s);_=G.surface.reduce((e,r)=>Math.min(e,r),w);let O=function(e,r,t,i,n){let l=new Uint8Array(t*i*2);for(let a=0;a<i;a++)for(let i=0;i<t;i++){let o=a*t+i;l[2*o]=e[o],l[2*o+1]=Math.min(255,r[i]-n)}return l}(G.mask,G.surface,S,w,_),k=(r=S,i=w,u=Math.round(b/t),d=i-Math.min(s,i),h=Math.max(14,Math.min(24,r-(f=Math.min(Math.round(.55*u),u-37-2))-37-4)),A=(T=Math.max(2,Math.min(f,r-37-4-h)))+37-2+h<=u?Math.max(4,d-h-10):6,{x:T,y:A}),z=function(e,r,t,i,l){let a=new Uint8Array(e*r*2);for(let e=0;e<t.length;e++)t[e]>128&&(a[2*e]=255);for(let[t,o]of n){let n=i+t,c=l+o;n>=0&&n<e&&c>=0&&c<r&&(a[(c*e+n)*2]=255)}return a}(S,w,G.mask,k.x,k.y);y=m(g,S,w,O,2),L=m(g,S,w,z,2),M=m(g,S,w,void 0,2),U=v(g,L),C=v(g,M)},N=()=>{g.disable(g.DEPTH_TEST),g.disable(g.CULL_FACE),g.disable(g.BLEND)};function B(){L&&(N(),g.bindFramebuffer(g.FRAMEBUFFER,null),g.viewport(0,0,e.width,e.height),g.clearColor(0,0,0,0),g.clear(g.COLOR_BUFFER_BIT),g.enable(g.BLEND),g.blendFunc(g.SRC_ALPHA,g.ONE_MINUS_SRC_ALPHA),g.useProgram(p),g.bindVertexArray(b),g.activeTexture(g.TEXTURE0),g.bindTexture(g.TEXTURE_2D,L),g.uniform1i(g.getUniformLocation(p,"uState"),0),g.uniform2i(g.getUniformLocation(p,"uGridSize"),S,w),g.uniform1f(g.getUniformLocation(p,"uCellPx"),t*R),g.uniform3f(g.getUniformLocation(p,"uCellColor"),T[0],T[1],T[2]),g.drawArrays(g.TRIANGLES,0,3),g.bindVertexArray(null),g.useProgram(null))}D(),B();let I=!document.hidden,G=0,O=null,k=!1,z=()=>{I=!document.hidden};document.addEventListener("visibilitychange",z);let X=0,j=()=>{cancelAnimationFrame(X),X=requestAnimationFrame(()=>{D(),B()})};window.addEventListener("resize",j);let W=e.parentElement,$=W?new ResizeObserver(j):null;W&&$&&$.observe(W);let V=e=>{k||(I&&e-G>=i&&(L&&y&&C&&(N(),g.bindFramebuffer(g.FRAMEBUFFER,C),g.viewport(0,0,S,w),g.useProgram(A),g.bindVertexArray(b),g.activeTexture(g.TEXTURE0),g.bindTexture(g.TEXTURE_2D,L),g.activeTexture(g.TEXTURE1),g.bindTexture(g.TEXTURE_2D,y),g.uniform1i(g.getUniformLocation(A,"uState"),0),g.uniform1i(g.getUniformLocation(A,"uMask"),1),g.uniform2i(g.getUniformLocation(A,"uGridSize"),S,w),g.uniform1i(g.getUniformLocation(A,"uMinSurfaceRow"),_),g.uniform1i(g.getUniformLocation(A,"uGen"),F),g.drawArrays(g.TRIANGLES,0,3),g.bindVertexArray(null),g.useProgram(null),g.bindFramebuffer(g.FRAMEBUFFER,null),F++,[L,M]=[M,L],[U,C]=[C,U]),B(),G=e),O=requestAnimationFrame(V))};return O=requestAnimationFrame(V),()=>{k=!0,null!==O&&cancelAnimationFrame(O),cancelAnimationFrame(X),document.removeEventListener("visibilitychange",z),window.removeEventListener("resize",j),$?.disconnect(),g.deleteVertexArray(b),P(),g.deleteProgram(A),g.deleteProgram(p)}}(e,{cellSize:10,speedMs:100,ditherRows:20*!!T,cellColor:A?[0,107/255,63/255]:void 0})}catch{return}return e.classList.remove("hidden"),R.current&&(R.current.hidden=!0),()=>{r?.()}},[A]),(0,r.jsxs)("section",{className:`relative isolate overflow-hidden bg-white ${t}`,style:p,"data-glider-hero":!0,children:[(0,r.jsx)("div",{className:"hero-grid","aria-hidden":"true"}),(0,r.jsx)("div",{className:"pix-glider-wrap","aria-hidden":"true",children:(0,r.jsx)("canvas",{ref:g,className:"hidden","data-glider-shader":!0})}),(0,r.jsx)("div",{ref:R,className:"absolute inset-x-0 bottom-0 z-[1]","aria-hidden":"true",children:T&&(0,r.jsx)(b,{tone:s})}),(0,r.jsx)("div",{className:"relative z-10",children:e})]})}let w=["/me/shop","/me/leaderboard"],_=["/me/orders"],F=["/me/orders"];function L(e,r){return r.some(r=>e===r||e.startsWith(`${r}/`))}e.s(["default",0,function({children:e,className:i}){let n=(0,t.usePathname)()??"",l=L(n,F)?"":"mx-auto max-w-7xl";return L(n,_)?(0,r.jsxs)("section",{className:`relative isolate min-h-[calc(100vh-var(--site-header-h,80px))] overflow-hidden bg-white ${i??""}`,children:[(0,r.jsx)("div",{className:"hero-grid","aria-hidden":"true"}),(0,r.jsx)("div",{className:`relative z-10 ${l}`,children:e})]}):L(n,w)?(0,r.jsx)("section",{className:`relative isolate overflow-hidden bg-white ${i??""}`,children:(0,r.jsx)("div",{className:`relative z-10 ${l}`,children:e})}):(0,r.jsx)(S,{className:i,tone:"govuk",dither:!1,children:(0,r.jsx)("div",{className:l,children:e})})}],381989)}]);

//# debugId=bbd1f08d-286c-a118-a431-d102491b1306